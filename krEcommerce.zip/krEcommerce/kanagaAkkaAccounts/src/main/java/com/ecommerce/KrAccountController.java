package com.ecommerce;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class KrAccountController {

	@Autowired
	private AccountServiceProperty accountServiceProperty;

	@GetMapping("/getProperties")
	public AccountServiceProperty getProperties() {
		return new AccountServiceProperty(accountServiceProperty.getMaximum(), accountServiceProperty.getMinimum());
	}

}
